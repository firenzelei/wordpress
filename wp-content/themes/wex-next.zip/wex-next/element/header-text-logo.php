<span class="logo-line-before"><i></i></span>
<a href="<?php bloginfo('url');?>" class="brand" rel="start">
              <span class="logo">
                <i class="icon-next-logo"></i>
            </span>

    <span class="site-title"><?php wexweb('site_name','请在后台设置您的站点名称')?></span>
</a>
<span class="logo-line-after"><i></i></span>