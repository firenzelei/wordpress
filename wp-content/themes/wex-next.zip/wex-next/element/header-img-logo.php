<img src="<?php wexweb('img_logo','http://www.imwex.cn/wp-content/uploads/2017/10/logo.png')?>" class="img-logo">
